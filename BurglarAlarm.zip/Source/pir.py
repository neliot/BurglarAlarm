from machine import Pin, Timer
from ssd1306 import SSD1306_I2C
#from sh1106 import SH1106_I2C
import framebuf
import time


# INITIALISATION

buzzer = Pin( 6,Pin.OUT)
buzz =   False
yes =    Pin(19,Pin.IN)
no =     Pin(18,Pin.IN)
reset =  Pin(15,Pin.IN, Pin.PULL_DOWN)
alerts = [Pin( 7,Pin.OUT,Pin.PULL_DOWN), Pin( 8,Pin.OUT,Pin.PULL_DOWN)]
pir =    [[Pin(26,Pin.IN,Pin.PULL_DOWN), 0, True],           # pir = [data,state,enabled]
          [Pin(20,Pin.IN,Pin.PULL_DOWN), 0, True]]           # power on GPIO for future control/reset of PIR work
led =    Pin(25,Pin.OUT)
i2c =    machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled =   SSD1306_I2C(128, 64, i2c)
#oled =   SH1106_I2C(128, 64, i2c)
#oled.rotate(180)

tim = Timer(period=1000, mode=Timer.PERIODIC, callback=lambda t:led.toggle()) # blinky to show I'm alive!

for alert in alerts:      # SWITCH OFF THE LEDS
    alert.value(0)
buzzer.value(0)

############################################################################################
# IRQ CALLBACKS
############################################################################################
def pir0callback(pin):
    global pir
    global alerts
    pir[0][0].irq(handler=None)
    if (pir[0][0].value() == 1) and (pir[0][2] == 0):
        pir[0][1] = 1
        print("PIR 0 Triggered")
        alerts[0].value(1)
        if buzz:
            print('BUZZ')
            buzzer.value(1)
    pir[0][0].irq(trigger=Pin.IRQ_RISING, handler=pir0callback)

def pir1callback(pin):
    global pir
    global alerts
    pir[1][0].irq(handler=None)
    if (pir[1][0].value() == 1) and (pir[1][1] == 0):
        pir[1][1] = 1
        print("PIR 1 Triggered")
        alerts[1].value(1)
        if buzz:
            print('BUZZ')
            buzzer.value(1)
    pir[1][0].irq(trigger=Pin.IRQ_RISING, handler=pir1callback)

def resetcallback(reset):
    reset.irq(handler=None)
    oled.fill(0)
    oled.text("SYSTEM RESET",20,20)                             # TITLE DISPLAY
    oled.show()
    time.sleep(5)
    machine.reset()

#################################################################
# MAIN CONFIG MENU
#################################################################

def basescreen():
    oled.fill(0)
    oled.rect(0,0,127,63,1)
    oled.rect(0,0,127,15,1)
    oled.text("Burglar Alarm!",8,4)

def pirstartup():
    basescreen()
    oled.text("PIR Init!",3,20)                             # TITLE DISPLAY
    oled.show()
    print("PIR Init!")                             # TITLE DISPLAY
    time.sleep(2)
    oled.text("PIR Armed!",3,40)                             # TITLE DISPLAY
    oled.show()
    print("PIR Armed!")                             # TITLE DISPLAY
    if pir[0][2]:
        pir[0][0].irq(trigger=Pin.IRQ_RISING, handler=pir0callback)
    if pir[1][2]:
        pir[1][0].irq(trigger=Pin.IRQ_RISING, handler=pir1callback)
    
def enableZones():
    counter = 0
    for _ in pir: 
        basescreen()
        oled.text("Enable Zone {}?".format(counter),6,20)
        oled.text("(Y/N)",45,30)
        oled.show()
        while yes.value() == 0 and no.value() == 0:
            pass
        if yes.value() == 1:
            pir[counter][2] = 1
            oled.text("Zone {} Enabled".format(counter),3,40)
        else:
            pir[counter][2] = 0
            oled.text("Zone {} Disabled".format(counter),3,40)
        oled.show()
        counter = counter + 1
        time.sleep(1)
        
def enableBuzzer():
    global buzz
    basescreen()
    oled.text("Enable Buzzer?",6,20)
    oled.text("(Y/N)",45,30)
    oled.show()
    while yes.value() == 0 and no.value() == 0:
        pass
    if yes.value() == 1:
        buzz = True
        oled.text("Buzzer Enabled!",3,40)
    else:
        buzz = False
        oled.text("Buzzer Disabled!",3,40)
    oled.show()
    time.sleep(1)

def config():
    reset.irq(trigger=Pin.IRQ_RISING, handler=resetcallback)
    enableZones()
    enableBuzzer()
    pirstartup()
    
##################################################################
# SYSTEM
##################################################################
       
config()

while True:
    pass

        

