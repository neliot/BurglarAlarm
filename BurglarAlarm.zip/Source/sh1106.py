#
# MicroPython SH1106 OLED driver, I2C and SPI interfaces
#
# The MIT License (MIT)
#
# Copyright (c) 2016 Radomir Dopieralski (@deshipu),
#               2017 Robert Hammelrath (@robert-hh)
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
# Sample code sections
# ------------ SPI ------------------
# Pin Map SPI
#   - 3V3      - Vcc
#   - GND      - Gnd
#   - GPIO 11  - DIN / MOSI fixed
#   - GPIO 10  - CLK / Sck fixed
#   - GPIO 4   - CS (optional, if the only connected device, connect to GND)
#   - GPIO 5   - D/C
#   - GPIO 2   - Res
#
# for CS, D/C and Res other ports may be chosen.
#
# from machine import Pin, SPI
# import sh1106

# spi = SPI(1, baudrate=1000000)
# display = sh1106.SH1106_SPI(128, 64, spi, Pin(5), Pin(2), Pin(4))
# display.sleep(False)
# display.fill(0)
# display.text('Testing 1', 0, 0, 1)
# display.show()
#
# --------------- I2C ------------------
#
# Pin Map I2C
#   - 3V3      - Vcc
#   - GND      - Gnd
#   - GPIO 5   - CLK / SCL
#   - GPIO 4   - DIN / SDA
#   - GPIO 2   - Res
#   - GND      - CS
#   - GND      - D/C
#
#
# from machine import Pin, I2C
# import sh1106
#
# i2c = I2C(0, scl=Pin(5), sda=Pin(4), freq=400000)
# display = sh1106.SH1106_I2C(128, 64, i2c, Pin(2), 0x3c)
# display.sleep(False)
# display.fill(0)
# display.text('Testing 1', 0, 0, 1)
# display.show()

from micropython import const
import utime as time
import framebuf


# a few register definitions
_SET_CONTRAST        = const(0x81)
_SET_NORM_INV        = const(0xa6)
_SET_DISP            = const(0xae)
_SET_SCAN_DIR        = const(0xc0)
_SET_SEG_REMAP       = const(0xa0)
_LOW_COLUMN_ADDRESS  = const(0x00)
_HIGH_COLUMN_ADDRESS = const(0x10)
_SET_PAGE_ADDRESS    = const(0xB0)


class SH1106:
    LEFT=0
    RIGHT=1
    UP=2
    DOWN=3
    DEG=4
    DASH=5
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = self.height // 8
        self.buffer = bytearray(self.pages * self.width)
        fb = framebuf.FrameBuffer(self.buffer, self.width, self.height,
                                  framebuf.MVLSB)
        self.framebuf = fb
# set shortcuts for the methods of framebuf
        self.fill = fb.fill
        self.fill_rect = fb.fill_rect
        self.hline = fb.hline
        self.vline = fb.vline
        self.line = fb.line
        self.rect = fb.rect
        self.pixel = fb.pixel
        self.scroll = fb.scroll
        self.text = fb.text
        self.blit = fb.blit

        self.init_display()

    def init_display(self):
        self.reset()
        self.fill(0)
        self.poweron()
        self.show()

    def poweroff(self):
        self.write_cmd(_SET_DISP | 0x00)

    def poweron(self):
        self.write_cmd(_SET_DISP | 0x01)

    def rotate(self, flag, update=True):
        if flag:
            self.write_cmd(_SET_SEG_REMAP | 0x01)  # mirror display vertically
            self.write_cmd(_SET_SCAN_DIR | 0x08)  # mirror display hor.
        else:
            self.write_cmd(_SET_SEG_REMAP | 0x00)
            self.write_cmd(_SET_SCAN_DIR | 0x00)
        if update:
            self.show()

    def sleep(self, value):
        self.write_cmd(_SET_DISP | (not value))

    def contrast(self, contrast):
        self.write_cmd(_SET_CONTRAST)
        self.write_cmd(contrast)

    def invert(self, invert):
        self.write_cmd(_SET_NORM_INV | (invert & 1))

    def show(self):
        for page in range(self.height // 8):
            self.write_cmd(_SET_PAGE_ADDRESS | page)
            self.write_cmd(_LOW_COLUMN_ADDRESS | 2)
            self.write_cmd(_HIGH_COLUMN_ADDRESS | 0)
            self.write_data(self.buffer[
                self.width * page:self.width * page + self.width
            ])

    def reset(self, res):
        if res is not None:
            res(1)
            time.sleep_ms(1)
            res(0)
            time.sleep_ms(20)
            res(1)
            time.sleep_ms(20)

    def horiz(self,xx,yy,size):
        for i in range(size):
            self.pixel(xx+i,yy,1)
            
    def vert(self,xx,yy,size):
        for i in range(size):
            self.pixel(xx,yy+i,1)

    def box(self,xx1,yy1,xx2,yy2):
        xs = xx2 - xx1
        ys = yy2 - yy1
        self.horiz(xx1,yy1,xs)
        self.horiz(xx1,yy2,xs)
        self.vert(xx1,yy1,ys)
        self.vert(xx1+xs,yy1,ys)
        
    def line(self,x1,y1,x2,y2):
        if x1 > x2:
            t = x1
            x1 = x2
            x2 = t
            t = y1
            y1 = y2
            y2 = t
        if x2-x1 == 0:
            vert(x1,y1,math.fabs(y1-y2))
        else:
            n=x2-x1+1
            grad = float((y2-y1)/(x2-x1))
            for i in range(n):
                y3 = y1 + int(grad * i)
                self.pixel(x1+i,y3,1)
                
    def circle(self,x,y,r):
        for angle in range(0,90,2):
            y3 = int(r*math.sin(math.radians(angle)))
            x3 = int(r*math.cos(math.radians(angle)))
            self.pixel(x-x3,y+y3,1)
            self.pixel(x-x3,y-y3,1)
            self.pixel(x+x3,y+y3,1)
            self.pixel(x+x3,y-y3,1)
            
    def string(self,x,y,data):
        for c in data:
            self.char(x,y,c)
            x = x + 10
            
    def char(self,xx,yy,sym):
        c = ord(sym) - 32
        xx = xx-5
        bits=[128,64,32,16,8,4,2,1]
        
        patterns = [
                    [ 1, 1, 1, 1, 1, 1, 1, 1],  #  32 " "
#                    [ 0, 0, 0, 0, 0, 0, 0, 0],  #  32 " "
                    [ 8, 8, 8, 8, 8, 0, 8, 0],  #  33 !
                    [10,10,10, 0, 0, 0, 0, 0],  #  34 "
                    [10,10,31,10,31,10,10, 0],  #  35 #
                    [ 4,15,20,14, 5, 5,30, 4],  #  35 $
                    [25,26, 2, 4, 4, 8,11,19],  #  37 %
                    [ 8,20,20, 8,13,18,18,13],  #  38 &
                    [ 8, 8, 8, 0, 0, 0, 0, 0],  #  39 '
                    [ 6, 8, 8, 8, 8, 8, 8, 6],  #  40 (
                    [ 12, 2, 2, 2, 2, 2,2,12],  #  41 )
                    [ 4,21,14, 4, 4,14,21, 4],  #  42 *
                    [ 0, 4, 4,14,14, 4, 4, 0],  #  43 +                    
                    [ 0, 0, 0, 0,12,12, 4, 8],  #  44 ,
                    [ 0, 0, 0,14,14, 0, 0, 0],  #  45 -
                    [ 0, 0, 0, 0, 0,12,12, 0],  #  46 .
                    [ 1, 2, 2, 4, 4, 8, 8,16],  #  47 /  
                    [12,18,18,18,18,18,18,12],  #  48 0
                    [ 4,12, 4, 4, 4, 4, 4,14],  #  49 1  
                    [12,18, 2, 4, 4, 8,16,30],  #  50 2
                    [12,18, 2,12,12, 2,18,12],  #  51 3
                    [ 4,12,20,20,30, 4, 4,14],  #  52 4
                    [30,16,16,28, 2, 2,18,12],  #  53 5
                    [12,18,16,28,18,18,18,12],  #  54 6
                    [30,18, 2, 4, 4, 8, 8,16],  #  55 7
                    [12,18,18,12,18,18,18,12],  #  56 8
                    [12,18,18,14, 2, 2,18,12],  #  57 9
                    [ 0, 0, 4, 0, 0, 4, 0, 0],  #  59 :
                    [ 0, 0, 4, 0, 0, 4, 4, 8],  #  60 ;
                    [ 0, 2, 4, 8,16, 8, 4, 2],  #  61 <
                    [ 0, 0,30, 0, 0,30, 0, 0],  #  62 =
                    [ 0,16, 8, 4, 2, 4, 8,16],  #  63 >
                    [12,18, 2, 4, 4, 4, 0, 4],  #  64 ?
                    [12,18,18,20,20,16,10, 4],  #  65 @
                    [12,18,18,30,18,18,18,18],  #  66 A
                    [28,18,18,28,18,18,18,28],  #  67 B
                    [12,18,18,16,16,18,18,12],  #  68 C
                    [28,18,18,18,18,18,18,28],  #  69 D
                    [30,16,16,28,16,16,16,30],  #  70 E
                    [30,16,16,28,16,16,16,16],  #  71 F
                    [12,18,16,22,18,18,18,16],  #  72 G
                    [18,18,18,30,18,18,18,18],  #  73 H
                    [14, 4, 4, 4, 4, 4, 4,14],  #  74 I
                    [30, 4, 4, 4, 4, 4,20,12],  #  75 J
                    [18,18,20,20,24,20,18,18],  #  76 K
                    [16,16,16,16,16,16,16,30],  #  77 L
                    [18,18,30,30,18,18,18,18],  #  78 M
                    [18,18,26,26,22,22,18,18],  #  71 N
                    [12,18,18,18,18,18,18,12],  #  72 O
                    [28,18,18,28,16,16,16,16],  #  73 P
                    [12,18,18,18,18,18,20,10],  #  74 Q
                    [12,18,18,28,18,18,18,18],  #  75 R
                    [12,18,16,12, 2, 2,18,12],  #  76 S
                    [30, 4, 4, 4, 4, 4, 4, 4],  #  77 T
                    [18,18,18,18,18,18,18,12],  #  78 U
                    [18,18,18,18,18,18,13, 4],  #  79 V
                    [18,18,18,18,18,22,30,18],  #  80 W
                    [18,18,18,12,18,18,18,18],  #  81 X
                    [18,18,18,12, 4, 4, 4, 4],  #  82 Y
                    [30, 2, 4,12, 8,24,16,30],  #  83 Z
                    [14, 8, 8, 8, 8, 8, 8,14],  #  84 [
                    [16, 8, 8, 4, 4, 2, 2, 1],  #  85 \
                    [14, 2, 2, 2, 2, 2, 2,14],  #  86 ]
                    [ 4,10, 4, 0, 0, 0, 0, 0],  #  87 ^ - CHANGED TO DEG
                    [ 0, 0, 0, 0, 0, 0, 0,31],  #  88 _
                    [ 8, 8, 0, 0, 0, 0, 0, 0],  #  89 `
                    [12,18,18,30,18,18,18,18],  #  66 A
                    [28,18,18,28,18,18,18,28],  #  67 B
                    [12,18,18,16,16,18,18,12],  #  68 C
                    [28,18,18,18,18,18,18,28],  #  69 D
                    [30,16,16,28,16,16,16,30],  #  70 E
                    [30,16,16,28,16,16,16,16],  #  71 F
                    [12,18,16,22,18,18,18,16],  #  72 G
                    [18,18,18,30,18,18,18,18],  #  73 H
                    [14, 4, 4, 4, 4, 4, 4,14],  #  74 I
                    [30, 4, 4, 4, 4, 4,20,12],  #  75 J
                    [18,18,20,20,24,20,18,18],  #  76 K
                    [16,16,16,16,16,16,16,30],  #  77 L
                    [18,18,30,30,18,18,18,18],  #  78 M
                    [18,18,26,26,22,22,18,18],  #  71 N
                    [12,18,18,18,18,18,18,12],  #  72 O
                    [28,18,18,28,16,16,16,16],  #  73 P
                    [12,18,18,18,18,18,20,10],  #  74 Q
                    [12,18,18,28,18,18,18,18],  #  75 R
                    [12,18,16,12, 2, 2,18,12],  #  76 S
                    [30, 4, 4, 4, 4, 4, 4, 4],  #  77 T
                    [18,18,18,18,18,18,18,12],  #  78 U
                    [18,18,18,18,18,18,13, 4],  #  79 V
                    [18,18,18,18,18,22,30,18],  #  80 W
                    [18,18,18,12,18,18,18,18],  #  81 X
                    [18,18,18,12, 4, 4, 4, 4],  #  82 Y
                    [30, 2, 4,12, 8,24,16,30],  #  83 Z
                    [ 6, 4, 4, 8, 4, 4, 4, 6],  #  98 {
                    [ 4, 4, 4, 4, 4, 4, 4, 4],  #  98 |
                    [12, 4, 4, 2, 4, 4, 4,12],  #  98 }
                    [30, 2, 4,12, 8,24,16,30]   #  83 ~
                   ]  
        
        for line in range(8):
            i = 0
            for ii in range(5):
                i = ii + 3
                dot = patterns[c][line] & bits[i]
                if dot:
                    self.pixel(xx+i*2,yy+line*2,1)
                    self.pixel(xx+i*2+1,yy+line*2,1)
                    self.pixel(xx+i*2,yy+line*2+1,1)
                    self.pixel(xx+i*2+1,yy+line*2+1,1)

    def sym(self,xx,yy,sym):
        xx=xx-5
        bits=[128,64,32,16,8,4,2,1]
        
        patterns = [
                    [ 0, 4, 8,31, 8, 4, 0, 0],  #  0 LEFT
                    [ 0, 4, 2,31, 2, 4, 0, 0],  #  1 RIGHT
                    [ 4,14,21, 4, 4, 4, 4, 4],  #  2 UP
                    [ 4, 4, 4, 4, 4,21,14, 4],  #  3 DOWN
                    [ 0,12,12, 0, 0, 0, 0, 0],  #  4 DEG
                    [ 0, 0, 0,31, 0, 0, 0, 0],  #  5 -
                   ]  
        
        for line in range(8):
            i = 0
            for ii in range(5):
                i = ii + 3
                dot = patterns[sym][line] & bits[i]
                if dot:
                    self.pixel(xx+i*2,yy+line*2,1)
                    self.pixel(xx+i*2+1,yy+line*2,1)
                    self.pixel(xx+i*2,yy+line*2+1,1)
                    self.pixel(xx+i*2+1,yy+line*2+1,1)



class SH1106_I2C(SH1106):
    def __init__(self, width, height, i2c, res=None, addr=0x3c,
                 external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        self.res = res
        self.temp = bytearray(2)
        if res is not None:
            res.init(res.OUT, value=1)
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.temp[0] = 0x80  # Co=1, D/C#=0
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)

    def write_data(self, buf):
        self.i2c.writeto(self.addr, b'\x40'+buf)

    def reset(self):
        super().reset(self.res)


class SH1106_SPI(SH1106):
    def __init__(self, width, height, spi, dc, res=None, cs=None,
                 external_vcc=False):
        self.rate = 10 * 1000 * 1000
        dc.init(dc.OUT, value=0)
        if res is not None:
            res.init(res.OUT, value=0)
        if cs is not None:
            cs.init(cs.OUT, value=1)
        self.spi = spi
        self.dc = dc
        self.res = res
        self.cs = cs
        super().__init__(width, height, external_vcc)

    def write_cmd(self, cmd):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        if self.cs is not None:
            self.cs(1)
            self.dc(0)
            self.cs(0)
            self.spi.write(bytearray([cmd]))
            self.cs(1)
        else:
            self.dc(0)
            self.spi.write(bytearray([cmd]))

    def write_data(self, buf):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        if self.cs is not None:
            self.cs(1)
            self.dc(1)
            self.cs(0)
            self.spi.write(buf)
            self.cs(1)
        else:
            self.dc(1)
            self.spi.write(buf)

    def reset(self):
        super().reset(self.res)