# MicroPython SSD1306 OLED driver, I2C and SPI interfaces
 
from micropython import const
import math
import framebuf
 
# register definitions
SET_CONTRAST = const(0x81)
SET_ENTIRE_ON = const(0xA4)
SET_NORM_INV = const(0xA6)
SET_DISP = const(0xAE)
SET_MEM_ADDR = const(0x20)
SET_COL_ADDR = const(0x21)
SET_PAGE_ADDR = const(0x22)
SET_DISP_START_LINE = const(0x40)
SET_SEG_REMAP = const(0xA0)
SET_MUX_RATIO = const(0xA8)
SET_COM_OUT_DIR = const(0xC0)
SET_DISP_OFFSET = const(0xD3)
SET_COM_PIN_CFG = const(0xDA)
SET_DISP_CLK_DIV = const(0xD5)
SET_PRECHARGE = const(0xD9)
SET_VCOM_DESEL = const(0xDB)
SET_CHARGE_PUMP = const(0x8D)
 
# Subclassing FrameBuffer provides support for graphics primitives
# http://docs.micropython.org/en/latest/pyboard/library/framebuf.html
class SSD1306(framebuf.FrameBuffer):
    LEFT=0
    RIGHT=1
    UP=2
    DOWN=3
    DEG=4
    DASH=5
    
    def __init__(self, width, height, external_vcc):
        self.width = width
        self.height = height
        self.external_vcc = external_vcc
        self.pages = self.height // 8
        self.buffer = bytearray(self.pages * self.width)
        super().__init__(self.buffer, self.width, self.height, framebuf.MONO_VLSB)
        self.init_display()
 
    def init_display(self):
        for cmd in (
            SET_DISP | 0x00,  # off
            # address setting
            SET_MEM_ADDR,
            0x00,  # horizontal
            # resolution and layout
            SET_DISP_START_LINE | 0x00,
            SET_SEG_REMAP | 0x01,  # column addr 127 mapped to SEG0
            SET_MUX_RATIO,
            self.height - 1,
            SET_COM_OUT_DIR | 0x08,  # scan from COM[N] to COM0
            SET_DISP_OFFSET,
            0x00,
            SET_COM_PIN_CFG,
            0x02 if self.width > 2 * self.height else 0x12,
            # timing and driving scheme
            SET_DISP_CLK_DIV,
            0x80,
            SET_PRECHARGE,
            0x22 if self.external_vcc else 0xF1,
            SET_VCOM_DESEL,
            0x30,  # 0.83*Vcc
            # display
            SET_CONTRAST,
            0xFF,  # maximum
            SET_ENTIRE_ON,  # output follows RAM contents
            SET_NORM_INV,  # not inverted
            # charge pump
            SET_CHARGE_PUMP,
            0x10 if self.external_vcc else 0x14,
            SET_DISP | 0x01,
        ):  # on
            self.write_cmd(cmd)
        self.fill(0)
        self.show()
 
    def poweroff(self):
        self.write_cmd(SET_DISP | 0x00)
 
    def poweron(self):
        self.write_cmd(SET_DISP | 0x01)
 
    def contrast(self, contrast):
        self.write_cmd(SET_CONTRAST)
        self.write_cmd(contrast)
 
    def invert(self, invert):
        self.write_cmd(SET_NORM_INV | (invert & 1))
 
    def show(self):
        x0 = 0
        x1 = self.width - 1
        if self.width == 64:
            # displays with width of 64 pixels are shifted by 32
            x0 += 32
            x1 += 32
        self.write_cmd(SET_COL_ADDR)
        self.write_cmd(x0)
        self.write_cmd(x1)
        self.write_cmd(SET_PAGE_ADDR)
        self.write_cmd(0)
        self.write_cmd(self.pages - 1)
        self.write_data(self.buffer)
        
    def deg(self,xx,yy):  # Draw Degree symbol
        self.pixel(xx,yy+1,1)
        self.pixel(xx,yy,1)
        self.pixel(xx+1,yy,1)
        self.pixel(xx+1,yy+1,1)
        
    def horiz(self,xx,yy,size):
        for i in range(size):
            self.pixel(xx+i,yy,1)
            
    def vert(self,xx,yy,size):
        for i in range(size):
            self.pixel(xx,yy+i,1)

    def box(self,xx1,yy1,xx2,yy2):
        xs = xx2 - xx1
        ys = yy2 - yy1
        self.horiz(xx1,yy1,xs)
        self.horiz(xx1,yy2,xs)
        self.vert(xx1,yy1,ys)
        self.vert(xx1+xs,yy1,ys)
        
    def line(self,x1,y1,x2,y2):
        if x1 > x2:
            t = x1
            x1 = x2
            x2 = t
            t = y1
            y1 = y2
            y2 = t
        if x2-x1 == 0:
            vert(x1,y1,math.fabs(y1-y2))
        else:
            n=x2-x1+1
            grad = float((y2-y1)/(x2-x1))
            for i in range(n):
                y3 = y1 + int(grad * i)
                self.pixel(x1+i,y3,1)
                
    def circle(self,x,y,r):
        for angle in range(0,90,2):
            y3 = int(r*math.sin(math.radians(angle)))
            x3 = int(r*math.cos(math.radians(angle)))
            self.pixel(x-x3,y+y3,1)
            self.pixel(x-x3,y-y3,1)
            self.pixel(x+x3,y+y3,1)
            self.pixel(x+x3,y-y3,1)
            
    def string(self,x,y,data):
        for c in data:
            self.char(x,y,c)
            x = x + 10
            
    def char(self,xx,yy,sym):
        c = ord(sym) - 32
        xx = xx-5
        bits=[128,64,32,16,8,4,2,1]
        
        patterns = [
                    [ 1, 1, 1, 1, 1, 1, 1, 1],  #  32 " "
#                    [ 0, 0, 0, 0, 0, 0, 0, 0],  #  32 " "
                    [ 8, 8, 8, 8, 8, 0, 8, 0],  #  33 !
                    [10,10,10, 0, 0, 0, 0, 0],  #  34 "
                    [10,10,31,10,31,10,10, 0],  #  35 #
                    [ 4,15,20,14, 5, 5,30, 4],  #  35 $
                    [25,26, 2, 4, 4, 8,11,19],  #  37 %
                    [ 8,20,20, 8,13,18,18,13],  #  38 &
                    [ 8, 8, 8, 0, 0, 0, 0, 0],  #  39 '
                    [ 6, 8, 8, 8, 8, 8, 8, 6],  #  40 (
                    [ 12, 2, 2, 2, 2, 2,2,12],  #  41 )
                    [ 4,21,14, 4, 4,14,21, 4],  #  42 *
                    [ 0, 4, 4,14,14, 4, 4, 0],  #  43 +                    
                    [ 0, 0, 0, 0,12,12, 4, 8],  #  44 ,
                    [ 0, 0, 0,14,14, 0, 0, 0],  #  45 -
                    [ 0, 0, 0, 0, 0,12,12, 0],  #  46 .
                    [ 1, 2, 2, 4, 4, 8, 8,16],  #  47 /  
                    [12,18,18,18,18,18,18,12],  #  48 0
                    [ 4,12, 4, 4, 4, 4, 4,14],  #  49 1  
                    [12,18, 2, 4, 4, 8,16,30],  #  50 2
                    [12,18, 2,12,12, 2,18,12],  #  51 3
                    [ 4,12,20,20,30, 4, 4,14],  #  52 4
                    [30,16,16,28, 2, 2,18,12],  #  53 5
                    [12,18,16,28,18,18,18,12],  #  54 6
                    [30,18, 2, 4, 4, 8, 8,16],  #  55 7
                    [12,18,18,12,18,18,18,12],  #  56 8
                    [12,18,18,14, 2, 2,18,12],  #  57 9
                    [ 0, 0, 4, 0, 0, 4, 0, 0],  #  59 :
                    [ 0, 0, 4, 0, 0, 4, 4, 8],  #  60 ;
                    [ 0, 2, 4, 8,16, 8, 4, 2],  #  61 <
                    [ 0, 0,30, 0, 0,30, 0, 0],  #  62 =
                    [ 0,16, 8, 4, 2, 4, 8,16],  #  63 >
                    [12,18, 2, 4, 4, 4, 0, 4],  #  64 ?
                    [12,18,18,20,20,16,10, 4],  #  65 @
                    [12,18,18,30,18,18,18,18],  #  66 A
                    [28,18,18,28,18,18,18,28],  #  67 B
                    [12,18,18,16,16,18,18,12],  #  68 C
                    [28,18,18,18,18,18,18,28],  #  69 D
                    [30,16,16,28,16,16,16,30],  #  70 E
                    [30,16,16,28,16,16,16,16],  #  71 F
                    [12,18,16,22,18,18,18,16],  #  72 G
                    [18,18,18,30,18,18,18,18],  #  73 H
                    [14, 4, 4, 4, 4, 4, 4,14],  #  74 I
                    [30, 4, 4, 4, 4, 4,20,12],  #  75 J
                    [18,18,20,20,24,20,18,18],  #  76 K
                    [16,16,16,16,16,16,16,30],  #  77 L
                    [18,18,30,30,18,18,18,18],  #  78 M
                    [18,18,26,26,22,22,18,18],  #  71 N
                    [12,18,18,18,18,18,18,12],  #  72 O
                    [28,18,18,28,16,16,16,16],  #  73 P
                    [12,18,18,18,18,18,20,10],  #  74 Q
                    [12,18,18,28,18,18,18,18],  #  75 R
                    [12,18,16,12, 2, 2,18,12],  #  76 S
                    [30, 4, 4, 4, 4, 4, 4, 4],  #  77 T
                    [18,18,18,18,18,18,18,12],  #  78 U
                    [18,18,18,18,18,18,13, 4],  #  79 V
                    [18,18,18,18,18,22,30,18],  #  80 W
                    [18,18,18,12,18,18,18,18],  #  81 X
                    [18,18,18,12, 4, 4, 4, 4],  #  82 Y
                    [30, 2, 4,12, 8,24,16,30],  #  83 Z
                    [14, 8, 8, 8, 8, 8, 8,14],  #  84 [
                    [16, 8, 8, 4, 4, 2, 2, 1],  #  85 \
                    [14, 2, 2, 2, 2, 2, 2,14],  #  86 ]
                    [ 4,10, 4, 0, 0, 0, 0, 0],  #  87 ^ - CHANGED TO DEG
                    [ 0, 0, 0, 0, 0, 0, 0,31],  #  88 _
                    [ 8, 8, 0, 0, 0, 0, 0, 0],  #  89 `
                    [12,18,18,30,18,18,18,18],  #  66 A
                    [28,18,18,28,18,18,18,28],  #  67 B
                    [12,18,18,16,16,18,18,12],  #  68 C
                    [28,18,18,18,18,18,18,28],  #  69 D
                    [30,16,16,28,16,16,16,30],  #  70 E
                    [30,16,16,28,16,16,16,16],  #  71 F
                    [12,18,16,22,18,18,18,16],  #  72 G
                    [18,18,18,30,18,18,18,18],  #  73 H
                    [14, 4, 4, 4, 4, 4, 4,14],  #  74 I
                    [30, 4, 4, 4, 4, 4,20,12],  #  75 J
                    [18,18,20,20,24,20,18,18],  #  76 K
                    [16,16,16,16,16,16,16,30],  #  77 L
                    [18,18,30,30,18,18,18,18],  #  78 M
                    [18,18,26,26,22,22,18,18],  #  71 N
                    [12,18,18,18,18,18,18,12],  #  72 O
                    [28,18,18,28,16,16,16,16],  #  73 P
                    [12,18,18,18,18,18,20,10],  #  74 Q
                    [12,18,18,28,18,18,18,18],  #  75 R
                    [12,18,16,12, 2, 2,18,12],  #  76 S
                    [30, 4, 4, 4, 4, 4, 4, 4],  #  77 T
                    [18,18,18,18,18,18,18,12],  #  78 U
                    [18,18,18,18,18,18,13, 4],  #  79 V
                    [18,18,18,18,18,22,30,18],  #  80 W
                    [18,18,18,12,18,18,18,18],  #  81 X
                    [18,18,18,12, 4, 4, 4, 4],  #  82 Y
                    [30, 2, 4,12, 8,24,16,30],  #  83 Z
                    [ 6, 4, 4, 8, 4, 4, 4, 6],  #  98 {
                    [ 4, 4, 4, 4, 4, 4, 4, 4],  #  98 |
                    [12, 4, 4, 2, 4, 4, 4,12],  #  98 }
                    [30, 2, 4,12, 8,24,16,30]   #  83 ~
                   ]  
        
        for line in range(8):
            i = 0
            for ii in range(5):
                i = ii + 3
                dot = patterns[c][line] & bits[i]
                if dot:
                    self.pixel(xx+i*2,yy+line*2,1)
                    self.pixel(xx+i*2+1,yy+line*2,1)
                    self.pixel(xx+i*2,yy+line*2+1,1)
                    self.pixel(xx+i*2+1,yy+line*2+1,1)

    def sym(self,xx,yy,sym):
        xx=xx-5
        bits=[128,64,32,16,8,4,2,1]
        
        patterns = [
                    [ 0, 4, 8,31, 8, 4, 0, 0],  #  0 LEFT
                    [ 0, 4, 2,31, 2, 4, 0, 0],  #  1 RIGHT
                    [ 4,14,21, 4, 4, 4, 4, 4],  #  2 UP
                    [ 4, 4, 4, 4, 4,21,14, 4],  #  3 DOWN
                    [ 0,12,12, 0, 0, 0, 0, 0],  #  4 DEG
                    [ 0, 0, 0,31, 0, 0, 0, 0],  #  5 -
                   ]  
        
        for line in range(8):
            i = 0
            for ii in range(5):
                i = ii + 3
                dot = patterns[sym][line] & bits[i]
                if dot:
                    self.pixel(xx+i*2,yy+line*2,1)
                    self.pixel(xx+i*2+1,yy+line*2,1)
                    self.pixel(xx+i*2,yy+line*2+1,1)
                    self.pixel(xx+i*2+1,yy+line*2+1,1)


class SSD1306_I2C(SSD1306):
    def __init__(self, width, height, i2c, addr=0x3C, external_vcc=False):
        self.i2c = i2c
        self.addr = addr
        self.temp = bytearray(2)
        self.write_list = [b"\x40", None]  # Co=0, D/C#=1
        super().__init__(width, height, external_vcc)
 
    def write_cmd(self, cmd):
        self.temp[0] = 0x80  # Co=1, D/C#=0
        self.temp[1] = cmd
        self.i2c.writeto(self.addr, self.temp)
 
    def write_data(self, buf):
        self.write_list[1] = buf
        self.i2c.writevto(self.addr, self.write_list)
 
 
class SSD1306_SPI(SSD1306):
    def __init__(self, width, height, spi, dc, res, cs, external_vcc=False):
        self.rate = 10 * 1024 * 1024
        dc.init(dc.OUT, value=0)
        res.init(res.OUT, value=0)
        cs.init(cs.OUT, value=1)
        self.spi = spi
        self.dc = dc
        self.res = res
        self.cs = cs
        import time
 
        self.res(1)
        time.sleep_ms(1)
        self.res(0)
        time.sleep_ms(10)
        self.res(1)
        super().__init__(width, height, external_vcc)
 
    def write_cmd(self, cmd):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        self.cs(1)
        self.dc(0)
        self.cs(0)
        self.spi.write(bytearray([cmd]))
        self.cs(1)
 
    def write_data(self, buf):
        self.spi.init(baudrate=self.rate, polarity=0, phase=0)
        self.cs(1)
        self.dc(1)
        self.cs(0)
        self.spi.write(buf)
        self.cs(1)
