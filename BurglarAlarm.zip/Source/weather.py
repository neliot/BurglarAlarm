############################################
# TITLE  # WEATHER APP
# AUTHOR # DR NEIL ELIOT
# DATE   # 08/01/2023
############################################
# NOTES
###################################################################################
# BEWARE ONLY USE THE INTERNAL DHT11 LIBRARY OR IT FREEZES
###################################################################################

from machine import Pin
from sh1106 import SH1106_I2C
from dht import DHT11
#import framebuf
import time

buzzer = Pin(6,Pin.OUT)
reset = Pin(15,Pin.OUT)
sensor = DHT11(Pin(7))
led = Pin(25,Pin.OUT)
i2c = machine.I2C(0,sda=Pin(16), scl=Pin(17), freq=400000)
oled = SH1106_I2C(128, 64, i2c)

prevTemp = 0
prevHumi = 0

def buzz():
    buzzer.value(1)
    time.sleep(0.01)
    buzzer.value(0)

while True:
    led.toggle()
    sensor.measure()                                             # READ DATA
    oled.fill(0)                                                 # CLEAR SCREEN
    oled.text("Weather Station",2,5)                             # TITLE DISPLAY
    oled.box(0,0,127,15)                                         # BOX TITLE
    oled.box(0,24,127,63)                                        # BOX READINGS
    oled.horiz(0,44,127)                                         # BOX READINGS
    oled.vert(111,24,48)                                         # BOX MOVEMENT
    newTemp = sensor.temperature()                                 # READ TEMP
    newHumi = sensor.humidity()                                    # READ HUMIDITY
    oled.string(0,26,"TEMP:{}^C".format(newTemp))                # DISPLAY TEMP
    oled.string(0,46,"HUMI:{}%".format(newHumi))                 # DISPLAY HUMIDITY

    if newTemp > prevTemp:                                       # TEMPERATURE GOING UP
        oled.sym(113,26,oled.UP)
        buzz()
    elif newTemp < prevTemp:                                     # TEMPERATURE GOING DOWN
        oled.sym(113,26,oled.DOWN)
        buzz()
    else:                                                        # STATIC TEMPERATURE
        oled.sym(113,26,oled.DASH)

    if newHumi > prevHumi:                                       # HUMIDITY GOING UP
        oled.sym(113,46,oled.UP)
        buzz()
    elif newHumi < prevHumi:                                     # HUMIDITY GOING DOWN
        oled.sym(113,46,oled.DOWN)
        buzz()
    else:                                                        # STATIC HUMIDITY
        oled.sym(113,46,oled.DASH)

    prevTemp = newTemp                                           # STORE NEW TEMP
    prevHumi = newHumi                                           # STORE NEW HUMIDITY

    if reset.value():                                            # RESET PICO
        machine.reset()
        
    oled.show()                                                  # DISPLAY THE SCREEN
    time.sleep(2)                                                # PAUSE 5 SECONDS
        

